const toggleButton = document.getElementById('toggleButton');
const moreDestinations = document.getElementById('moreDestinations');

toggleButton.addEventListener('click', () => {
    if (moreDestinations.classList.contains('hidden')) {
        moreDestinations.classList.remove('hidden');
        toggleButton.textContent = 'Less Destinations';
    } else {
        moreDestinations.classList.add('hidden');
        toggleButton.textContent = 'More Destinations';
    }
});



const viewAllButton = document.getElementById("viewAllPackagesButton");
    const viewLessButton = document.getElementById("viewLessPackagesButton");
    const hiddenPackages = document.querySelectorAll(".hidden-packages");

    viewAllButton.addEventListener("click", function() {
        hiddenPackages.forEach(package => {
            package.classList.remove("hidden");  
        });
        viewAllButton.classList.add("hidden");  
        viewLessButton.classList.remove("hidden");  
    });

    viewLessButton.addEventListener("click", function() {
        hiddenPackages.forEach(package => {
            package.classList.add("hidden");  
        });
        viewAllButton.classList.remove("hidden"); 
        viewLessButton.classList.add("hidden");  
    });